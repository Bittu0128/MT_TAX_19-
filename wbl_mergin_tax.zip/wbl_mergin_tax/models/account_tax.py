from odoo import models, fields,api

class AccountTax(models.Model):
    _inherit = 'account.tax'

    margin_tax_bool = fields.Boolean(string='Mergin Tax', default=False)
