from odoo import models, fields, api
from collections import defaultdict


class AccountTax(models.Model):
    _inherit = 'account.tax'

    margin_tax_bool = fields.Boolean(string='Margin Tax', default=True)

    @api.model
    def _get_tax_totals_summary(self, base_lines, currency, company, cash_rounding=None):
        res = super()._get_tax_totals_summary(base_lines, currency, company, cash_rounding)
        if not res or not res.get('subtotals'):
            return res

        total_base_amount = 0.0
        total_tax_amount = 0.0
        total_sale_amount = 0.0

        grouped_tax_data = defaultdict(lambda: {
            'tax_amount': 0.0,
            'base_amount': 0.0,
            'tax': None,
        })

        for base_line in base_lines:
            product = base_line.get('product_id')
            price_unit = base_line.get('price_unit', 0.0)
            quantity = base_line.get('quantity', 0.0)

            if not product or not isinstance(product, models.BaseModel):
                continue

            cost = product.standard_price or 0.0
            sale_total = price_unit * quantity
            margin_total = max(price_unit - cost, 0.0) * quantity

            taxes_data = base_line.get('tax_details', {}).get('taxes_data', [])
            for tax_data in taxes_data:
                tax = tax_data.get('tax')
                if not tax:
                    continue

                if tax.margin_tax_bool:
                    tax_amount = margin_total * (tax.amount / 100.0)
                    base_amount = sale_total - tax_amount
                else:
                    compute_res = tax.compute_all(
                        price_unit,
                        currency=currency,
                        quantity=quantity,
                        product=product,
                        partner=None
                    )
                    tax_amount = compute_res['total_included'] - compute_res['total_excluded']
                    base_amount = compute_res['total_excluded']

                grouped_tax_data[tax.id]['tax_amount'] += tax_amount
                grouped_tax_data[tax.id]['base_amount'] += base_amount
                grouped_tax_data[tax.id]['tax'] = tax

                total_tax_amount += tax_amount
                total_base_amount += base_amount
                total_sale_amount += sale_total

        # Update the global summary totals
        res.update({
            'base_amount_currency': total_base_amount,
            'tax_amount_currency': total_tax_amount,
            'total_amount_currency': total_base_amount + total_tax_amount,
            'base_amount': total_base_amount,
            'tax_amount': total_tax_amount,
            'total_amount': total_base_amount + total_tax_amount,
        })

        # Update each subtotal and its tax groups
        if res.get('subtotals'):
            subtotal = res['subtotals'][0]
            subtotal.update({
                'base_amount_currency': total_base_amount,
                'tax_amount_currency': total_tax_amount,
                'base_amount': total_base_amount,
                'tax_amount': total_tax_amount,
            })

            for group in subtotal.get('tax_groups', []):
                tax_ids = group.get('involved_tax_ids', [])
                if tax_ids:
                    tax_id = tax_ids[0]
                    tax_data = grouped_tax_data.get(tax_id)
                    if tax_data:
                        group.update({
                            'base_amount_currency': tax_data['base_amount'],
                            'tax_amount_currency': tax_data['tax_amount'],
                            'base_amount': tax_data['base_amount'],
                            'tax_amount': tax_data['tax_amount'],
                            'display_base_amount_currency': tax_data['base_amount'],
                            'display_base_amount': tax_data['base_amount'],
                        })

        return res
