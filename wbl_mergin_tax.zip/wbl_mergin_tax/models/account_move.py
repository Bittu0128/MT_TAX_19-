from odoo import models, fields, api


class AccountMove(models.Model):
    _inherit = 'account.move'

    # amount_untaxed = fields.Monetary(
    #     string='Untaxed Amount',
    #     store=True, readonly=True,
    #     currency_field='currency_id',
    #     compute='_compute_amount'
    # )
    # amount_tax = fields.Monetary(
    #     string='Tax',
    #     store=True,readonly=True,
    #     currency_field='currency_id',
    #     compute='_compute_amount'
    # )
    # amount_total = fields.Monetary(
    #     string='Total',
    #     store=True, readonly=True,
    #     currency_field='currency_id',
    #     compute='_compute_amount'
    # )
    #
    # def _compute_amount(self):
    #     for move in self:
    #         move.amount_untaxed = sum(line.price_subtotal for line in move.invoice_line_ids)
    #         move.amount_total = sum(line.price_total for line in move.invoice_line_ids)
    #         move.amount_tax = move.amount_total - move.amount_untaxed

            # print(move.amount_untaxed)
            # print(move.amount_tax)
            # print(move.amount_total)
