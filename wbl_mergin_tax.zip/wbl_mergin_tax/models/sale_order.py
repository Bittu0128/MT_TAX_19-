from odoo import models, fields, api

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    # amount_untaxed = fields.Monetary(string='Untaxed Amount', store=True, readonly=True, compute='_compute_amounts', currency_field='currency_id')
    # amount_tax = fields.Monetary(string='Tax', store=True, readonly=True, compute='_compute_amounts', currency_field='currency_id')
    # amount_total = fields.Monetary(string='Total', store=True, readonly=True, compute='_compute_amounts', currency_field='currency_id')
    #
    # @api.depends('order_line.product_id', 'order_line.price_unit', 'order_line.product_uom_qty', 'order_line.tax_id')
    # def _compute_amounts(self):
    #     for order in self:
    #         untaxed = 0.0
    #         tax = 0.0
    #         for line in order.order_line:
    #             if line.display_type:
    #                 continue
    #
    #             cost = line.product_id.standard_price or 0.0
    #             price = line.price_unit or 0.0
    #             qty = line.product_uom_qty or 0.0
    #             margin = price - cost
    #
    #             # Sum all margin tax rates if multiple
    #             tax_rate = sum(tax.amount / 100.0 for tax in line.tax_id if tax.margin_tax_bool)
    #
    #             if margin > 0 and tax_rate > 0:
    #                 margin_total = margin * qty
    #                 # Inclusive tax on margin calculation
    #                 line_tax = margin_total - (margin_total / (1 + tax_rate))
    #             else:
    #                 line_tax = 0.0
    #
    #             line_total = price * qty
    #             untaxed += line_total - line_tax
    #             tax += line_tax
    #
    #         order.amount_untaxed = untaxed
    #         order.amount_tax = tax
    #         order.amount_total = untaxed + tax  # total should match total price including tax

