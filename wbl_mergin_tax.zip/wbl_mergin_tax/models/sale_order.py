from odoo import models, api, fields


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    amount_untaxed = fields.Monetary(string='Untaxed Amount', store=True, readonly=True, compute='_amount_all', currency_field='currency_id')
    amount_tax = fields.Monetary(string='Tax', store=True, readonly=True, compute='_amount_all', currency_field='currency_id')
    amount_total = fields.Monetary(string='Total', store=True, readonly=True, compute='_amount_all', currency_field='currency_id')

    @api.depends('order_line.price_subtotal', 'order_line.price_total', 'order_line.price_tax')
    def _amount_all(self):
        for order in self:
            order.amount_untaxed = sum(line.price_subtotal for line in order.order_line)
            order.amount_total = sum(line.price_total for line in order.order_line)
            order.amount_tax = order.amount_total - order.amount_untaxed

            # print(order.amount_untaxed)
            # print(order.amount_tax)
            # print(order.amount_total)





