from odoo import models, api, fields


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    cost_price = fields.Float(string="Unit Cost", compute="_compute_cost_price", store=True)
    margin = fields.Float(string="Margin", compute='_compute_margin_and_subtotal', store=True)
    price_subtotal = fields.Monetary(string='Subtotal', compute='_compute_margin_and_subtotal', store=True)
    price_tax = fields.Monetary(string='Tax (on Margin)', compute='_compute_margin_and_subtotal', store=True)
    price_total = fields.Monetary(string='Total', compute='_compute_margin_and_subtotal', store=True)

    @api.depends('product_id')
    def _compute_cost_price(self):
        for line in self:
            line.cost_price = line.product_id.standard_price if line.product_id else 0.0

    @api.depends('quantity', 'price_unit', 'cost_price', 'tax_ids')
    def _compute_margin_and_subtotal(self):
        for line in self:
            quantity = line.quantity or 0.0
            sale_price = line.price_unit or 0.0
            cost_price = line.cost_price or 0.0
            unit_margin = sale_price - cost_price
            total_margin = unit_margin * quantity

            total_tax = 0.0
            for tax in line.tax_ids:
                if tax.amount_type == 'percent':
                    total_tax += total_margin * (tax.amount / 100.0)

            line.margin = total_margin
            line.price_tax = total_tax
            line.price_total = (sale_price * quantity)
            line.price_subtotal = line.price_total - total_tax


