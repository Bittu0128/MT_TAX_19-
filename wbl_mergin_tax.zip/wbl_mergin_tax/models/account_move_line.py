from odoo import models, api, fields


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    price_subtotal = fields.Monetary(
        string='Subtotal',
        compute='_compute_price_subtotal',
        store=True,
    )

    margin = fields.Float(
        string="Margin",
        compute='_compute_margin',
        store=True,
    )

    @api.depends('product_id', 'price_unit')
    def _compute_margin(self):
        for line in self:
            # Ensure both prices are valid
            sale_price = line.price_unit or 0.0
            cost_price = line.product_id.standard_price if line.product_id else 0.0

            line.margin = sale_price - cost_price
            # print(line.margin)

    @api.depends('margin', 'quantity', 'tax_ids', 'product_id', 'price_unit')
    def _compute_price_subtotal(self):
        for line in self:
            sale_price = line.price_unit or 0.0
            cost_price = line.product_id.standard_price if line.product_id else 0.0

            line.margin = sale_price - cost_price
            quantity = line.quantity
            sale_price = line.price_unit
            margin_total = line.margin * quantity
            tax = line.tax_ids.amount
            print(margin_total)
            tax_on_margin = (margin_total * tax) / 100
            print(tax_on_margin)
            line.price_subtotal = (sale_price - tax_on_margin) * quantity
            print(line.price_subtotal)
