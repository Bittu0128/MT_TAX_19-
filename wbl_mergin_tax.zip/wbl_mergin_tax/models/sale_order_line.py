from odoo import models, fields, api
from odoo.exceptions import ValidationError


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    cost_price = fields.Float(string='Unit Cost', compute='_compute_cost_price', store=True)
    margin = fields.Float(string="Margin", compute='_compute_margin', store=True)
    margin_percent = fields.Float(string="Margin %", compute='_compute_margin', store=True)

    price_tax = fields.Monetary(string='Tax (on Margin)', compute='_compute_amount', store=True)
    price_total = fields.Monetary(string='Total', compute='_compute_amount', store=True)
    price_subtotal = fields.Monetary(string='Subtotal', compute='_compute_amount', store=True)

    @api.depends('product_id')
    def _compute_cost_price(self):
        for line in self:
            line.cost_price = line.product_id.standard_price if line.product_id else 0.0

    @api.depends('price_unit', 'cost_price', 'product_uom_qty')
    def _compute_margin(self):
        for line in self:
            if not line.cost_price:
                line.margin = 0.0
                line.margin_percent = 0.0
                continue

            unit_margin = line.price_unit - line.cost_price
            line.margin = unit_margin * line.product_uom_qty

            if line.price_unit > 0:
                line.margin_percent = (unit_margin / line.price_unit)
            else:
                line.margin_percent = 0.0

    @api.depends('product_uom_qty', 'price_unit', 'cost_price', 'tax_id')
    def _compute_amount(self):
        for line in self:
            qty = line.product_uom_qty or 0.0
            price_unit = line.price_unit or 0.0
            cost_price = line.cost_price or 0.0

            unit_margin = price_unit - cost_price
            total_margin = unit_margin * qty
            total_price = price_unit * qty
            total_tax = 0.0
            for tax in line.tax_id:
                if tax.amount_type == 'percent':
                    tax_rate = tax.amount / 100.0
                    tax_on_margin = total_margin * tax_rate
                    total_tax += tax_on_margin

            line.price_tax = total_tax
            line.price_total = total_price  # Inclusive price
            line.price_subtotal = total_price - total_tax  # Excluding tax (margin base)

    @api.onchange('product_id')
    def _onchange_product_id_margin_tax(self):
        if self.product_id:
            margin_taxes = self.env['account.tax'].search([('margin_tax_bool', '=', True)])
            if margin_taxes:
                self.tax_id = margin_taxes
            else:
                fpos = self.order_id.fiscal_position_id
                taxes = self.product_id.taxes_id
                if fpos:
                    taxes = fpos.map_tax(taxes, self.product_id, self.order_id.partner_id)
                self.tax_id = taxes

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            product_id = vals.get('product_id')
            if product_id:
                product = self.env['product.product'].browse(product_id)
                if product.standard_price <= 0:
                    raise ValidationError(
                        (
                            "You cannot add the product '%s' to the order because its cost price is zero or less.") % product.display_name
                    )
        return super().create(vals_list)

    # def _prepare_base_line_for_taxes_computation(self, **kwargs):
    #     res = super()._prepare_base_line_for_taxes_computation()
    #     res.update({
    #         'product': self.product_id.id,
    #         'price_unit': self.price_unit,
    #         'quantity': self.product_uom_qty,
    #         'taxes': self.tax_id.ids,
    #         'cost_price': self.product_id.standard_price,
    #         'rate': self.order_id.currency_rate,
    #         **kwargs,
    #         })
    #     return res
